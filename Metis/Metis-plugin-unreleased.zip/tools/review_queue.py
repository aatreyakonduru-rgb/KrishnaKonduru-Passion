#!/usr/bin/env python3
"""The review queue: what is waiting for certification, grouped by the team that owns it, riskiest first.

    python3 review_queue.py queue   <kb>                          every pending file, by owning team
    python3 review_queue.py plan    <kb> [--date YYYY-MM-DD]      write one PR body per team under <kb>/_PENDING/_QUEUE/ and print the branch names
    python3 review_queue.py certify <kb> --team NAME --by NAME [--accept-review NOTE]
                                                                  certify every pending file that team owns, across all batches

Ownership comes from `gate.teams` in <kb>/.metis/kb-profile.yaml: [{name, owns: [path globs], approvers: [names]}]. The first team
whose glob matches a file owns it. A file no team owns waits under "(no owning team)" for the leads. With no `gate.teams`, the
queue is one group and nothing else about the gate changes. Leads can still certify any file.

`plan` does not touch git. It names the branch `metis/<date>-review-<team>` and writes the PR body (files, risk, findings, who
should approve), so one PR can go to each team. Mētis never merges.
"""
import argparse
import datetime
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import kb_gate  # noqa: E402

QUEUE_DIR = "_QUEUE"


def queue(kb):
    """{"teams": [{team, approvers, files: [...]}]} with every pending file placed under its owning team, riskiest first.
    Teams appear in profile order, then the unowned group. Teams with nothing waiting are left out."""
    by_team = {}
    for batch in kb_gate.batches(kb):
        for r in kb_gate.analyse(kb, batch):
            t = kb_gate.team_of(kb, r["file"])
            by_team.setdefault(t["name"] if t else kb_gate.UNASSIGNED, []).append(dict(r, batch=batch))
    order = [t["name"] for t in kb_gate.teams(kb)] + [kb_gate.UNASSIGNED]
    leads = sorted(v[0] for v in kb_gate.certifiers(kb).values())
    out = []
    for name in order:
        files = by_team.get(name)
        if not files:
            continue
        team = next((t for t in kb_gate.teams(kb) if t["name"] == name), None)
        approvers = sorted(set((team["approvers"] if team else []) + leads), key=str.lower)
        out.append({"team": name, "approvers": approvers, "files": sorted(files, key=lambda r: (-r["risk"], r["file"]))})
    return {"teams": out}


def branch_name(team, date):
    return "metis/%s-review-%s" % (date, kb_gate.slug(team))


def pr_body(group, date):
    files = group["files"]
    L = ["# Certify: %s" % group["team"], "",
         "Knowledge pieces waiting for certification. Mētis does not merge this PR; an approver below does, after reading the list.", "",
         "- Approvers: %s" % (", ".join(group["approvers"]) or "none named in the profile"),
         "- Files: %d (%d new, %d changed, %d removed)" % (len(files), sum(r["action"] == "new" for r in files),
                                                          sum(r["action"] == "change" for r in files), sum(r["action"] == "remove" for r in files)),
         "- Blocked by a secret or id number: %d" % sum(any(f["level"] == "block" for f in r["findings"]) for r in files),
         "- Date: %s" % date, "",
         "| Order | File | Batch | What | Lines | Risk | Why it ranks here |", "|---|---|---|---|---|---|---|"]
    for i, r in enumerate(files, 1):
        why = ["%s (%s)" % (f["kind"], f["level"]) for f in r["findings"][:3]]
        if r["problems"]:
            why.append("%d source problems" % len(r["problems"]))
        if r["action"] == "remove":
            why.append("removes a certified file")
        L.append("| %d | %s | %s | %s | +%d -%d | %d | %s |" % (i, r["file"], r["batch"], r["action"], r["lines_added"], r["lines_removed"],
                                                             r["risk"], "; ".join(why) or "none found"))
    given = sorted({g for r in files for g in r["given_by"]})
    if given:
        L += ["", "Documents were given by: %s. They do not certify their own pages while another approver exists." % ", ".join(given)]
    return "\n".join(L) + "\n"


def plan(kb, date=None):
    """Write one PR body per team; return [{team, branch, body_file, files}]."""
    date = date or datetime.date.today().isoformat()
    base = os.path.join(kb_gate.pending_dir(kb), QUEUE_DIR)
    out = []
    for group in queue(kb)["teams"]:
        os.makedirs(base, exist_ok=True)
        path = os.path.join(base, "%s.md" % kb_gate.slug(group["team"]))
        with open(path, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(pr_body(group, date))
        out.append({"team": group["team"], "branch": branch_name(group["team"], date), "body_file": path,
                    "files": [r["file"] for r in group["files"]]})
    return out


def certify_team(kb, team, by, accept_review=None):
    """Certify every pending file the named team owns, in every batch. Returns the number of files certified."""
    name = kb_gate.clean(team).lower()
    group = next((g for g in queue(kb)["teams"] if g["team"].lower() == name), None)
    if not group:
        raise kb_gate.GateError("nothing is waiting for %s" % (kb_gate.clean(team) or "(no team)"))
    by_batch = {}
    for r in group["files"]:
        by_batch.setdefault(r["batch"], []).append(r["file"])
    # each batch is all-or-nothing; a refusal stops the run and leaves the later batches waiting
    done = 0
    for batch, files in sorted(by_batch.items()):
        done += kb_gate.certify(kb, batch, by, files, accept_review)
    return done


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("queue"); a.add_argument("kb")
    a = sub.add_parser("plan"); a.add_argument("kb"); a.add_argument("--date")
    a = sub.add_parser("certify"); a.add_argument("kb"); a.add_argument("--team", required=True)
    a.add_argument("--by", required=True); a.add_argument("--accept-review")
    args = ap.parse_args(argv)
    kb = os.path.abspath(args.kb)
    try:
        if args.cmd == "queue":
            q = queue(kb)["teams"]
            if not q:
                print("nothing is waiting for certification")
            for g in q:
                print("%s (%d files; approvers: %s)" % (g["team"], len(g["files"]), ", ".join(g["approvers"]) or "none named"))
                for r in g["files"]:
                    print("  risk %-4d %-7s %s  [%s]" % (r["risk"], r["action"], r["file"], r["batch"]))
        elif args.cmd == "plan":
            rows = plan(kb, args.date)
            if not rows:
                print("nothing is waiting for certification")
            for p in rows:
                print("%s: branch %s, %d files, PR body %s" % (p["team"], p["branch"], len(p["files"]), p["body_file"]))
        else:
            print("certified %d files for %s by %s" % (certify_team(kb, args.team, args.by, args.accept_review), kb_gate.clean(args.team), kb_gate.clean(args.by)))
    except kb_gate.GateError as err:
        print("error: %s" % err, file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
